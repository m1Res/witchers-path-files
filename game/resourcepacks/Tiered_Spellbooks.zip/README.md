Rebalances spell books by making them tiered.

This datapack adds recipes to tiered spellbooks, and also hides them from the Spell Binding table, requiring the player to craft them.

**By default it's separated by three tiers:**

Tier 1: Spell Binding Table
Tier 2: Upgrade from existing Tier 1 Spellbook
Tier 3: Crafted using a Nether Star (* Suggested to change according to your modpack's needs)

**Affected Mods:**
- Rogues and Warriors
- Death Knights
- Archers Expansion
- Spellblades and Such
- Paladins
- Runic Invocations

This is the same tiered system that the Prominence II RPG modpack uses, with the difference being that instead of using Nether Stars, it uses Cinderstone Trophies.