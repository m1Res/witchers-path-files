Adds recipe compatibility between Mythic Upgrades and Advanced Netherite, making a requirement of using Netherite-Diamond for Mythic Upgrades instead of normal Netherite.

Heavily suggested to use Custom Item Attributes to rebalance attributes if necessary, considering some of these armor sets might be weaker than Netherite-Diamond stat-wise.